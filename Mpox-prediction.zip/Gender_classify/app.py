import os
from flask import Flask, redirect, render_template, request, url_for
import numpy as np
import pickle

app = Flask(__name__)

@app.route("/", methods=("GET", "POST"))
def index():
    if request.method == "POST":
        # Get input data from the form
        d1 = float(request.form["rp"])
        d2 = float(request.form["st"])
        d3 = float(request.form["po"])
        d4 = float(request.form["ol"])
        d5 = float(request.form["sl"])
        d6 = float(request.form["sto"])
        d7 = float(request.form["hiv"])
        d8 = float(request.form["sti"])
        d9 = float(request.form["si"])
        d10 = float(request.form["sil"])

        # Prepare the input data for the model
        X_new = np.array([d1, d2, d3, d4, d5, d6, d7, d8, d9, d10]).reshape(1, -1)

        # Load the model from the pickle file
        model_pkl_file = "model.pkl"
        with open(model_pkl_file, 'rb') as file:
            model = pickle.load(file)

        # Make a prediction with the model
        y_predict = model.predict(X_new)

        # Convert the prediction to "Positive" or "Negative"
        result = "Positive" if y_predict[0] == 1 else "Negative"

        # Redirect to the index page with the result as a query parameter
        return redirect(url_for("index", result=result))

    # Get the result from the query parameters, if any
    result = request.args.get("result")
    
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
